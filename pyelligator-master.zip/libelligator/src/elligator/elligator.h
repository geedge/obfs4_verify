//
// This library is a derivative of agl's "ed25519/extra25519" go package
// distributed under the following license:
//
//   Copyright 2013 The Go Authors. All rights reserved.
//   Use of this source code is governed by a BSD-style
//   license that can be found in the LICENSE file.
//

#ifndef ELLIGATOR_ELLIGATOR_H__
#define ELLIGATOR_ELLIGATOR_H__

#include <stdint.h>
#include <stdbool.h>

/* __BEGIN_DECLS should be used at the beginning of your declarations,
   so that C++ compilers don't mangle their names.  Use __END_DECLS at
   the end of C declarations. */
#undef __BEGIN_DECLS
#undef __END_DECLS
#undef __REF
#ifdef __cplusplus
# define __BEGIN_DECLS extern "C" {
# define __END_DECLS }
# define __REF &
#else
# define __BEGIN_DECLS /* empty */
# define __END_DECLS /* empty */
# define __REF /* empty */
#endif


#ifdef __cplusplus
#include <cstddef>

namespace elligator {

const std::size_t PublicKeyLength = 32;
const std::size_t PrivateKeyLength = 32;
const std::size_t RepresentativeLength = 32;
#else
# define PublicKeyLength		32
# define	PrivateKeyLength	32
# define RepresentativeLength		32
#endif

typedef uint8_t PublicKey[PublicKeyLength];
typedef uint8_t PrivateKey[PrivateKeyLength];
typedef uint8_t Representative[RepresentativeLength];

__BEGIN_DECLS

bool ScalarBaseMult(PublicKey __REF publicKey,
                    Representative __REF representative,
                    const PrivateKey __REF privateKey);

void RepresentativeToPublicKey(PublicKey __REF publicKey,
                               const Representative __REF representative);

__END_DECLS

#ifdef __cplusplus
} // namespace elligator
#endif

#endif
